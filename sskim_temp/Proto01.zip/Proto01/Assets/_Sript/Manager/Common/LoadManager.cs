﻿using UnityEngine;
using System.Collections;


public enum eLoadType
{
    Scene,
    UI,

}
public class LoadManager : SingleTon<LoadManager>
{ 
}
