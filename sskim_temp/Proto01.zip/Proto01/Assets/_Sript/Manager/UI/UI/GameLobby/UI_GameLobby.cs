﻿using UnityEngine;
using System.Collections;

public class UI_GameLobby : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//Debug.Log ("Start!!!!");
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	public void onClikSetButton(){
		//Debug.Log ("SetButton Click!");
	}
}