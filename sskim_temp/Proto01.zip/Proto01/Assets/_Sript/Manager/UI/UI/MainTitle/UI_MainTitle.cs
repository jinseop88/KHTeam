﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class UI_MainTitle : MonoBehaviour
{
	public GameObject loginPopup;
	public GameObject inputBox;

	UIInput input;
	UIPanel panel;

	string playName;
	int i = 0;

	//Game Start!
	void Start () {
		Debug.Log("Game On!");
		PlayerPrefs.DeleteAll();

		// login Popup Visible off
		panel = loginPopup.GetComponent<UIPanel>();
		input = inputBox.GetComponent<UIInput> ();
		popUpOff ();
	}

	// Update is called once per frame
	void Update () {
	}
		
	// Button Event
	public void popupInCreateButtonClick(){
		createPlayer ();
	}

	public void popupInCancelButtonClick(){
		popUpOff ();
	}
		
    public void startButtonClick() {
		startGame ();
    }


	// Main Function
	public void startGame(){
		Debug.Log("Game Start!");

		Debug.Log(PlayerPrefs.GetString("PlayName") + "who?");

		// Player Not Exist
		if (PlayerPrefs.GetString("PlayName")==null || PlayerPrefs.GetString("PlayName").Equals("")) {
			Debug.Log ("Player Not Exist");
			popUpOn();
		} else {
			//Move To GameLobby
			UnityEngine.SceneManagement.SceneManager.LoadScene("2.GameLobby");
		}
	}

		
	// Popup Function
	public void createPlayer(){
		/*
		Player Imformation
		string playName = "";	//이름
		int weaponLevel = 1;	//무기레벨
		int stage = 0;			//클리어한 스테이지 번호
		int playHp;				//생명력
		int maxItemNumber;		//소지가능한 아이템 개수
		List<int> inventory = new List<int>();
		*/

		playName = input.label.text;
		if (playName.Equals ("") && playName == null) {
			Debug.Log ("Create Fail!");
		} else {
			PlayerPrefs.SetString ("PlayName", playName);
			PlayerPrefs.SetInt ("HP", 100);
			PlayerPrefs.SetInt ("WeponLevel", 1);
			PlayerPrefs.SetInt ("ClearStage", 0);
			Debug.Log ("Create Success!");
			popUpOff ();
		}
	}

	public void popUpOn(){
		Debug.Log ("Login Popup Open");
		panel.enabled = true;
	}

	public void popUpOff(){
		Debug.Log ("Login Popup close");
		panel.enabled = false;
	}
}