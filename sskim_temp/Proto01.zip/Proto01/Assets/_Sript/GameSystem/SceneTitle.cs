﻿using UnityEngine;
using System.Collections;

public class SceneTitle : SceneBase
{
    public override void Update()
    { 
    }

    public override void Restart()
    {
    }

    public override void Terminate()
    {
    }

    public override void Enter()
    {
    }

    public override void Exit()
    {
        base.Exit();
    }


}
