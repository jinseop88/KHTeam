﻿using UnityEngine;
using System.Collections;

public static class GameDefine 
{
    //public static const int MAX_CARD_COUNT = 30;
}

